package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

public class CriminalBackground extends AppCompatActivity {

    private CheckBox cbFirstYes, cbSecondYes, cbThirdYes, cbFourthAYes, cbFourthBYes, cbFourthCYes,
                    cbFirstNo, cbSecondNo, cbThirdNo, cbFourthANo, cbFourthBNo, cbFourthCNo;
    private EditText edtTxtFirst, edtTxtSecond, edtTxtThird, edtTxtFourthA, edtTxtFourthB, edtTxtFourthC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_criminal_background);
        getSupportActionBar().setTitle("CRIMINAL BACKGROUND");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        cbFirstYes = findViewById(R.id.chckboxYes1);
        cbFirstNo = findViewById(R.id.chckboxNo1);
        cbSecondYes = findViewById(R.id.chckboxYes2);
        cbSecondNo = findViewById(R.id.chckboxNo2);
        cbThirdYes = findViewById(R.id.chckboxYes3);
        cbThirdNo = findViewById(R.id.chckboxNo3);
        cbFourthAYes = findViewById(R.id.chckboxYes4);
        cbFourthANo = findViewById(R.id.chckboxNo4);
        cbFourthBYes = findViewById(R.id.chckboxYes5);
        cbFourthBNo = findViewById(R.id.chckboxNo5);
        cbFourthCYes = findViewById(R.id.chckboxYes6);
        cbFourthCNo = findViewById(R.id.chckboxNo6);

        edtTxtFirst = findViewById(R.id.edtTxtNumber1);
        edtTxtSecond = findViewById(R.id.edtTxtNumber2);
        edtTxtThird = findViewById(R.id.edtTxtNumber3);
        edtTxtFourthA = findViewById(R.id.edtTxtNumber4A);
        edtTxtFourthB = findViewById(R.id.edtTxtNumber4B);
        edtTxtFourthC = findViewById(R.id.edtTxtNumber4C);

        cbFirstYes.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
               if (isChecked) {
                   enablingFields();
               } else {
                   edtTxtFirst.setEnabled(false);
               }
            }
        });

        cbFirstNo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    edtTxtFirst.setEnabled(false);
                } else {
                    edtTxtFirst.setEnabled(true);
                }
            }
        });

        cbSecondYes.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    enablingFields();
                } else {
                    edtTxtSecond.setEnabled(false);
                }
            }
        });

        cbSecondNo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    edtTxtSecond.setEnabled(false);
                } else {
                    edtTxtSecond.setEnabled(true);
                }
            }
        });

        cbThirdYes.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    enablingFields();
                } else {
                    edtTxtThird.setEnabled(false);
                }
            }
        });

        cbThirdNo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    edtTxtThird.setEnabled(false);
                } else {
                    edtTxtThird.setEnabled(true);
                }
            }
        });

        cbFourthAYes.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    enablingFields();
                } else {
                    edtTxtFourthA.setEnabled(false);
                }
            }
        });

        cbFourthANo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    edtTxtFourthA.setEnabled(false);
                } else {
                    edtTxtFourthA.setEnabled(true);
                }
            }
        });

        cbFourthBYes.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    enablingFields();
                } else {
                    edtTxtFourthB.setEnabled(false);
                }
            }
        });

        cbFourthBNo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    edtTxtFourthB.setEnabled(false);
                } else {
                    edtTxtFourthB.setEnabled(true);
                }
            }
        });

        cbFourthCYes.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    enablingFields();
                } else {
                    edtTxtFourthC.setEnabled(false);
                }
            }
        });

        cbFourthCNo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    edtTxtFourthC.setEnabled(false);
                } else {
                    edtTxtFourthC.setEnabled(true);
                }
            }
        });
    }

    public void toReport(View v) {
        if (validatingForm()) {
            Toast.makeText(CriminalBackground.this, "Form submitted, proceeding to the next page", Toast.LENGTH_LONG).show();
            Intent toRep = new Intent(CriminalBackground.this, Report_Activity.class);
            startActivity(toRep);
        }
    }
    private void enablingFields() {

            boolean firstyesSelected = cbFirstYes.isChecked();
            boolean secondyesSelected = cbSecondYes.isChecked();
            boolean thirdyesSelected = cbThirdYes.isChecked();
            boolean fourth1yesSelected = cbFourthAYes.isChecked();
            boolean fourth2yesSelected = cbFourthBYes.isChecked();
            boolean fourth3yesSelected = cbFourthCYes.isChecked();

        edtTxtFirst.setEnabled(firstyesSelected);
        edtTxtSecond.setEnabled(secondyesSelected);
        edtTxtThird.setEnabled(thirdyesSelected);
        edtTxtFourthA.setEnabled(fourth1yesSelected);
        edtTxtFourthB.setEnabled(fourth2yesSelected);
        edtTxtFourthC.setEnabled(fourth3yesSelected);
    }

    private boolean validatingForm() {
        if (cbFirstYes.isChecked() && (edtTxtFirst.getText().toString().trim().isEmpty())) {
            return false;
        } else if (cbFirstNo.isChecked()) {
            return false;
        } else if (cbSecondYes.isChecked() && (edtTxtSecond.getText().toString().trim().isEmpty())) {
            return false;
        } else if (cbSecondNo.isChecked()) {
            return false;
        } else if (cbThirdYes.isChecked() && (edtTxtThird.getText().toString().trim().isEmpty())) {
            return false;
        } else if (cbThirdNo.isChecked()) {
            return false;
        } else if (cbFourthAYes.isChecked() && (edtTxtFourthA.getText().toString().trim().isEmpty())) {
            return false;
        } else if (cbFourthANo.isChecked()) {
            return false;
        } else if (cbFourthBYes.isChecked() && (edtTxtFourthB.getText().toString().trim().isEmpty())) {
            return false;
        } else if (cbFourthBNo.isChecked()) {
            return false;
        } else if (cbFourthCYes.isChecked() && (edtTxtFourthC.getText().toString().trim().isEmpty())) {
            return false;
        } else if (cbFourthCNo.isChecked()) {
            return false;
        } else {
            return true;
        }
    }
}